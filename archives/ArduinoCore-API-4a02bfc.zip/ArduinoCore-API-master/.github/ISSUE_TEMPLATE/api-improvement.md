---
name: API improvement
about: Suggest an improvement to an existing API component.
title: ""
labels: enhancement
assignees: ""
---

### API component

<!-- Tell us which API component the improvement applies to. -->

### Description

<!-- A clear and concise description of the suggestion. -->

### Is this a breaking change?

<!-- Would this change require any users to change their code? -->
<!-- Would this change require any boards platform authors to change their configuration files or release system? -->

### Additional information

<!-- Add any other context for the request here. -->
