---
name: New API component
about: Suggest the addition of a new API component to ArduinoCore-API.
title: ""
labels: enhancement
assignees: ""
---

### Description

<!-- A clear and concise description of the API component you want added. -->

### Additional information

<!-- Add any other context for the request here. -->
