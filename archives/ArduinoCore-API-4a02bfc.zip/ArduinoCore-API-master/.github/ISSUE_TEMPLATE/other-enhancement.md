---
name: Other enhancement
about:
  Suggest an improvement for this project that doesn't fit in the specific categories
  above.
title: ""
labels: enhancement
assignees: ""
---

### Description

<!-- A clear and concise description of the enhancement. -->

### Is this a breaking change?

<!-- Would this change require any users to change their code? -->
<!-- Would this change require any boards platform authors to change their configuration files or release system? -->

### Additional information

<!-- Add any other context for the request here. -->
