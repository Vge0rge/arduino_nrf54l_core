/*
 * Copyright (c) 2020 Arduino.  All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

/**************************************************************************************
 * INCLUDE/MAIN
 **************************************************************************************/

#define CATCH_CONFIG_MAIN
#include <catch.hpp>
