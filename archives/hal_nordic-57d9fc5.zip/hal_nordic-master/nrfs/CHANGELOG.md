# Changelog
All notable changes to this project are documented in this file.

## [1.0.0] - 07.05.2024
### Added
- initial release
### Changed

### Fixed
