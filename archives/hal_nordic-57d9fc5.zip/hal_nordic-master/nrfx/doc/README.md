# nrfx documentation

## Doxygen

You can generate `doxygen` based documentation by running

```shell
doxygen nrfx.doxyfile
```

You may want to use the provided scripts `generate_html_doc.sh` or
`generate_html_doc.bat`. The result can be viewed by opening
`html/index.html`.
