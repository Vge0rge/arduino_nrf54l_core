rm -rf html xml
doxygen nrfx.doxyfile
